
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">	
    <!-- OPTIONAL: description -->
    <meta name="description" content="">
    <!-- OPTIONAL: author -->
    <meta name="author" content="">
    <link rel="shortcut icon" href="favicon.ico">
    <link rel="apple-touch-icon" href="icon.png" />
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
		
    <title>Uddeshya Kumar</title>

    
    <link href="css/bootstrap.css" rel="stylesheet">
    <link rel="stylesheet" href="css/font-awesome.min.css">

   
    <link href="css/main.css" rel="stylesheet">
    
    

    <link href='//fonts.googleapis.com/css?family=Lato:300,400,700,300italic,400italic' rel='stylesheet' type='text/css'>
    <link href='//fonts.googleapis.com/css?family=Raleway:400,300,700' rel='stylesheet' type='text/css'>

<script>
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','https://www.google-analytics.com/analytics.js','ga');

  ga('create', 'UA-96350777-1', 'auto');
  ga('send', 'pageview');

</script>

<script>
function validateEmail(emailField){
        var reg = /^([A-Za-z0-9_\-\.])+\@([A-Za-z0-9_\-\.])+\.([A-Za-z]{2,4})$/;

        if (reg.test(emailField.value) == false) 
        {
            alert('Invalid Email Address');
            return false;
        }

        return true;
}
</script>
  </head>

  <body>

  
 
<script> 
$(document).ready(function(){
    $("button").click(function(){
        $("danim").animate({left: '600px'});
    });
});
</script>

<script>
$(document).ready(function(){
    $("button").click(function(){
        $("x").toggleClass("togg");
    });
});
</script>
	
	<div id="header" class="header">
		
			<button>Click Me</button> 
			<danim style="position:absolute;">
			<img src="./images/uddy.png" alt="Smiley face"  style="color:white; margin-left: 25px;height:150px; width:150px; "></danim>
					<h1 style="margin-left: 25px"><br><br>Uddeshya Kumar</h1>
					<x style="margin-left: 25px">IT Professional | <a href="mailto:uddeshyakumar30@gmail.com" target="_blank" >uddeshyakumar30@gmail.com </a></h3></x>
				
			
	</div>
	
	<a href="index.php"><b><center><font color="black">HOME!</font></b></center></a></br>
  <a href="Biodata.php"><b><center><font color="black">BIODATA!</font></b></center></a></br>
  <a href="Contactme.php"><b><center><font color="black">CONTACT ME!</b></font></center></a>
	
	

	<div id="contact"></div>
	
	<div id="footwrap" class="footer">
		<div class="container">
			<div class="row">
			
				<div class="col-lg-2 col-lg-offset-1">
															 
				</div>
				
				<div class="col-lg-6">
									 
} 
<left><button onclick="myFunction()">Contact Via</button></left>
<p id="demo"></p>

<center>
<script>
function myFunction() {
    document.getElementById("demo").innerHTML = "Address<br/>21 Vernon Terrace <br/>Poughkeepsie, NY, 12601 <br/>United States of America<br/>					Contact No. +1 845 518 6902<br/>uddeshyakumar30@gmail.com ";
}
</script>
</center>

				</div>
				<div class="col-lg-3">
					<p>SOCIAL LINKS</p>
					<p>
						
						<a href="https://www.linkedin.com/in/uddeshya-kumar-454241139/" target="_blank"><i class="icon-linkedin"></i></a>
						<a href="https://www.facebook.com/uddeshya" target="_blank"><i class="icon-facebook"></i></a>
						
						
					</p>
				</div>
			</div>
		</div>
		<div class="con">
		<center><form method="POST" action="https://formspree.io/uddeshyakumar30@gmail.com"><br>
		<p>Name:</p><input type="name" name="name" placeholder="Name"><br>
		<p>Subject</p><input type="name" name="subject" placeholder="Subject"><br>
  <p>Enter your email:</p><input type="email" name="email" placeholder="Your email" onblur="validateEmail(this);"><br>
  <p>Message</p><textarea name="message" placeholder="Your message"></textarea>
  <select id="Reasonforcontact" name="Reason of Contact"></select> </br></br>
            <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.11.0/jquery.min.js"></script>
<script >
              var $select = $('#Reasonforcontact');
              $.getJSON('data.json', function(data){
                

                for (var i = 0; i < data['Reasonforcontact'].length; i++) {
                 $select.append('<option id="' + data['Reasonforcontact'][i]['id'] + '">' + data['Reasonforcontact'][i]['name'] + '</option>');
                 }
              });
          </script>

  <button type="submit">Send</button></center>
</form>

		</div>
	</div>
  </body>
</html>
