
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">	
    <!-- OPTIONAL: description -->
    <meta name="description" content="">
    <!-- OPTIONAL: author -->
    <meta name="author" content="">
    <link href="css/bootstrap.css" rel="stylesheet">
    <link rel="stylesheet" href="css/font-awesome.min.css">   
    <link href="css/main.css" rel="stylesheet">
    <link href='//fonts.googleapis.com/css?family=Lato:300,400,700,300italic,400italic' rel='stylesheet' type='text/css'>
    <link href='//fonts.googleapis.com/css?family=Raleway:400,300,700' rel='stylesheet' type='text/css'>

    <link rel="shortcut icon" href="favicon.ico">
    <link rel="apple-touch-icon" href="icon.png" />
		
    <title>Uddeshya Kumar</title>

    
  </head>

  <body>
 

	
	<div id="header" class="header">
		
			<button>Click Me</button> 
			<danim style="position:absolute;">
			<img src="./images/uddy.png" alt="Smiley face"  style="color:white; margin-left: 25px;height:150px; width:150px; "></danim>
					
		
					
					<h1 style="margin-left: 25px"><br><br>Uddeshya Kumar</h1>
					



					
					<x style="margin-left: 25px">IT Professional | <a href="mailto:uddeshyakumar30@gmail.com" target="_blank" >uddeshyakumar30@gmail.com </a></h3></x>
				
			
	</div>
	

<a href="index.php"><b><center><font color="black">HOME!</font></b></center></a></br>
  <a href="Biodata.php"><b><center><font color="black">BIODATA!</font></b></center></a></br>
  <a href="Contactme.php"><b><center><font color="black">CONTACT ME!</b></font></center></a>
	<div id="about" ></div>
	<div class="about">
		<div class="container">
			<div class="row">

			<div class="col-lg-2 col-lg-offset-1">
					<h5>About Me</h5>
				</div>
				<div class="col-lg-6">
					
					<p>Quality-oriented professional committed in bringing out the best in the company using my skills and expertise in QA management. Proficient and helpful in producing only the best and quality products of the company and to prove as an asset to the organization. </p>
				</div>
				<div class="col-lg-3">

				<a href="uddy_captcha.html">Download Pdf</a>
					
					<p><a href="Uddy.pdf" download style="color: rgb(255,255,255); text-decoration:none;">DOWNLOAD PDF</a></p>
				</div>
				
			</div>
		</div>
	</div>

	<div id="resume"></div>
	
	<div class="container desc">
		<div class="row">

				<div class="col-lg-2 col-lg-offset-1">
					<h5>Educational Background</h5>
				</div>
				
				<div class="col-lg-6">
					<p>MS in Information Systems<br/>
						Marist College Poughkeepsie NY
					</p>
				</div>
				<div class="col-lg-3">
					<p>Expected SPRING 2018<br/>
					IN PROGRESS
					</p>
				</div>
	
				
				<div class="col-lg-6 col-lg-offset-3">
					<p>Bachelor of Technology (I.T.) <br/>
						 BVUCOE Pune India
						
					</p>
				</div>
				<div class="col-lg-3">
					<p>July 2013</p>
				</div>
	
		</div>
		<br>
		<hr>
	</div>
	
	
	<div class="container desc">
		<div class="row">

				<div class="col-lg-2 col-lg-offset-1">
					<h5>Professional Experience</h5>
				</div>
				
				<div class="col-lg-6">
					<p class="tight">Manual Tester Jan 2014- Jul 2016<br/>
						Samson Software Solutions Inc. Noida, UP, India<br/>
					</p>
					<p>Edoors is the software used primarily to fetch resumes routed via various Job Portals, post job requirements for the recruiters to look into it. This web based application has a database of resumes routed from portals such as Monster, Dice, Tech-fetch, Career Builder, Pro-hire, etc. Edoors helps the Sales team post requirements and on the other hand, the recruitment team works on the requirements as per the posting done on Edoors. Fetching of resumes by putting the String as per the requirement is done. This software’s dynamic nature helps update all the information on the portal and works out to be very efficient for the Recruitment division.</p>
				</div>
				
				
				
				<div class="col-lg-6 col-lg-offset-3">
					<p class="tight">Business Development Executive Jul 2013-Dec 2013<br/>
						Okaya Infocom Noida, UP, India<br/>
					</p>
					<p>IT Recruitment, Talent acquisition, Resource Management, sales & marketing strategy to generate leads, maintain high activity level with prospects and timely follow-ups, built and maintained sales pipeline status and respond to client’s technical queries and follow-ups. Actively involved in co-ordinating development of detailed technical proposals with the technical team.</p>
				</div>
				
		</div>
		<br>
		<hr>
	</div>


	
	<div class="container desc">
		<div class="row">
				<div class="col-lg-2 col-lg-offset-1">
					<h5>Awards & Achievements</h5>
				</div>

				
				<div class="col-lg-6">
					<p>Publicity Head (2012) & Part of Creative team (2012) & ACIES Member (2011-12)<br/></p>
				</div>
				
				
				<div class="col-lg-6 col-lg-offset-3">
					<p class="tight">Winner in Fashion Shows & Tug-o-War (2011&2012) <br/></p>
					
				</div>
				
		</div>
		<br>
	</div>
	

	<div id="contact"></div>
	
	<div id="footwrap" class="footer">
		<div class="container">
			<div class="row">
			
				<div class="col-lg-2 col-lg-offset-1">
				
				
											 
				</div>
				
				<div class="col-lg-6">
				
					 
} 





					
					
				</div>
				
				</div>
			</div>
		</div>
	</div>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>

<script>
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','https://www.google-analytics.com/analytics.js','ga');

  ga('create', 'UA-96350777-1', 'auto');
  ga('send', 'pageview');

</script>

<script> 
$(document).ready(function(){
    $("button").click(function(){
        $("danim").animate({left: '600px'});
    });
});
</script>

<script>
$(document).ready(function(){
    $("button").click(function(){
        $("x").toggleClass("togg");
    });
});
</script>

  </body>
</html>
